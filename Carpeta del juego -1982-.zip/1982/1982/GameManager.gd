extends Node

static var spawn_door: String = ""
