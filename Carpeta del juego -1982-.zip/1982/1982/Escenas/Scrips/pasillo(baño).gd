extends Node2D

func _ready() -> void:
	# Imprime todos los hijos del pasillo
	for child in get_children():
		print("nodo hijo: ", child.name)
	
	var door_id = GameManager.spawn_door
	if door_id == "":
		return
	var spawn = $Spawpoint.get_node_or_null(door_id)
	if spawn == null:
		print("⚠️ No existe spawn: ", door_id)
		return
	var player = get_node_or_null("CharacterBody2D")
	if player == null:
		print("⚠️ No encontró el jugador")
		return
	player.global_position = spawn.global_position
