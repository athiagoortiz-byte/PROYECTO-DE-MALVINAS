extends Control

@onready var master_slider = $HSlider
@onready var music_slider = $HSlider2

const SAVE_FILE = "user://settings.cfg"

func _ready():

	# Conectar señales
	master_slider.value_changed.connect(_on_master_slider_changed)
	music_slider.value_changed.connect(_on_music_slider_changed)

	load_settings()

# =========================
# MASTER VOLUME
# =========================
func _on_master_slider_changed(value):

	var bus = AudioServer.get_bus_index("Master")

	if value <= 0:
		AudioServer.set_bus_volume_db(bus, -80)
	else:
		AudioServer.set_bus_volume_db(
			bus,
			linear_to_db(value)
		)

	save_settings()

# =========================
# MUSIC VOLUME
# =========================
func _on_music_slider_changed(value):

	var bus = AudioServer.get_bus_index("Music")

	if value <= 0:
		AudioServer.set_bus_volume_db(bus, -80)
	else:
		AudioServer.set_bus_volume_db(
			bus,
			linear_to_db(value)
		)

	save_settings()

# =========================
# SAVE
# =========================
func save_settings():

	var config = ConfigFile.new()

	config.set_value(
		"audio",
		"master_volume",
		master_slider.value
	)

	config.set_value(
		"audio",
		"music_volume",
		music_slider.value
	)

	config.save(SAVE_FILE)

# =========================
# LOAD
# =========================
func load_settings():

	var config = ConfigFile.new()

	var err = config.load(SAVE_FILE)

	# Primera vez
	if err != OK:

		master_slider.value = 1.0
		music_slider.value = 1.0

		_on_master_slider_changed(1.0)
		_on_music_slider_changed(1.0)

		save_settings()

		return

	# Cargar valores guardados
	var master_volume = config.get_value(
		"audio",
		"master_volume",
		1.0
	)

	var music_volume = config.get_value(
		"audio",
		"music_volume",
		1.0
	)

	master_slider.value = master_volume
	music_slider.value = music_volume

	_on_master_slider_changed(master_volume)
	_on_music_slider_changed(music_volume)
