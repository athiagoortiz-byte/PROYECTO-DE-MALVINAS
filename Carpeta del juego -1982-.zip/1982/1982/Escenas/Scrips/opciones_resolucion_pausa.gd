extends Control

@onready var label = $VboxOpciones/Label
@onready var izq = $VBoxI/IZQ
@onready var der = $VBoxD/DER

var opciones = [
	"Pantalla Completa",
    "Ventana"
]
var index = 0

func _ready():
	# Leer el modo actual al iniciar para sincronizar el índice
	var modo_actual = DisplayServer.window_get_mode()
	if modo_actual == DisplayServer.WINDOW_MODE_EXCLUSIVE_FULLSCREEN:
		index = 0
	else:
		index = 1
	
	label.text = opciones[index]  # Solo actualiza el texto, sin aplicar cambio
	izq.pressed.connect(_izq)
	der.pressed.connect(_der)

func actualizar():
	label.text = opciones[index]
	aplicar_modo()

func aplicar_modo():
	match index:
		0:
			DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_EXCLUSIVE_FULLSCREEN)
		1:
			DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED)
			# Opcional: maximizar la ventana para simular "ventana completa"
			DisplayServer.window_set_flag(DisplayServer.WINDOW_FLAG_BORDERLESS, false)
			await get_tree().process_frame  # Esperar un frame antes de maximizar
			DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_MAXIMIZED)

func _izq():
	index -= 1
	if index < 0:
		index = opciones.size() - 1
	actualizar()

func _der():
	index += 1
	if index >= opciones.size():
		index = 0
	actualizar()
