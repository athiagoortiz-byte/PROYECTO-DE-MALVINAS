extends Button

func _on_pressed() -> void:
	pass # Replace with function body.
	get_tree().quit()
