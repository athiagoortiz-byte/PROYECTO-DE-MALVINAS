extends VBoxContainer

func _on_opciones_pressed() -> void:
	pass # Replace with function body.
	get_tree().change_scene_to_file ("res://Escenas/Pausa/OpcionesPausa.tscn")
