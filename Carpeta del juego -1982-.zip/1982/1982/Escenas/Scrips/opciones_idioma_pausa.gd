extends Control

@onready var label_idioma = $VboxOpciones/Label
@onready var boton_izq = $VBoxI/IZQ
@onready var boton_der = $VBoxD/DER

var idiomas = [
	"Español",
	"English",
]

var indice_actual = 0

func _ready():
	actualizar_texto()

	boton_izq.pressed.connect(_on_izq_pressed)
	boton_der.pressed.connect(_on_der_pressed)

func actualizar_texto():
	label_idioma.text = idiomas[indice_actual]

func _on_izq_pressed():
	indice_actual -= 1

	if indice_actual < 0:
		indice_actual = idiomas.size() - 1

	actualizar_texto()

func _on_der_pressed():
	indice_actual += 1

	if indice_actual >= idiomas.size():
		indice_actual = 0

	actualizar_texto()
