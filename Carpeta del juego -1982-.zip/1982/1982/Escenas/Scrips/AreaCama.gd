extends Area2D

@onready var cama_superpuesta: TextureRect = get_parent().get_node("CamaSuperpuesta")

func _ready() -> void:
	body_entered.connect(_on_body_entered)
	body_exited.connect(_on_body_exited)

func _on_body_entered(body: Node2D) -> void:
	if body is CharacterBody2D:
		cama_superpuesta.visible = false

func _on_body_exited(body: Node2D) -> void:
	if body is CharacterBody2D:
		cama_superpuesta.visible = true
