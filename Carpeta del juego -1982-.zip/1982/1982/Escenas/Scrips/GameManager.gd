extends Node

var spawn_door: String = ""
