extends Button

func _on_pressed() -> void:
	pass # Replace with function body.
	get_tree().quit()

func _on_atrass_pressed() -> void:
	pass # Replace with function body.
	get_tree().change_scene_to_file("res://Escenas/Pausa/OpcionesPausa.tscn")
