extends Button




func _on_pressed() -> void:
	pass # Replace with function body.
	get_tree().change_scene_to_file("res://Escenas/Menu/Opciones.tscn")
