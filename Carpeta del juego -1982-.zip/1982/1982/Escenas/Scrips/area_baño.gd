extends Area2D

@export var escena_destino: String = ""
@export var door_id: String = ""

var jugador_dentro: bool = false
var tecla_e: Node = null

func _ready() -> void:
	body_entered.connect(_on_body_entered)
	body_exited.connect(_on_body_exited)

func _on_body_entered(body: Node2D) -> void:
	if body is CharacterBody2D:
		jugador_dentro = true
		tecla_e = body.get_node_or_null("TeclaE")
		if tecla_e:
			tecla_e.visible = true

func _on_body_exited(body: Node2D) -> void:
	if body is CharacterBody2D:
		jugador_dentro = false
		if tecla_e:
			tecla_e.visible = false
		tecla_e = null

func _input(event: InputEvent) -> void:
	if jugador_dentro and event is InputEventKey:
		if event.keycode == KEY_E and event.pressed and not event.echo:
			if door_id != "":
				GameManager.spawn_door = door_id
			get_tree().change_scene_to_file(escena_destino)
