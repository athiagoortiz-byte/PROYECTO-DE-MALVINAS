extends Control

func _on_atras_boton_pressed() -> void:
	get_tree().change_scene_to_file("res://Escenas/Menu/Menu.tscn")

func _on_audio_boton_pressed() -> void:
	pass # Replace with function body.
	get_tree().change_scene_to_file("res://Escenas/Menu/AudioOpciones.tscn")

func _on_resolucion_boton_pressed() -> void:
	pass
	get_tree().change_scene_to_file("res://Escenas/Menu/ResolucionOpciones.tscn")
	
