extends Control

func _on_jugar_boton_pressed() -> void:
	pass # Replace with function body.


func _on_opciones_boton_pressed() -> void:
	get_tree().change_scene_to_file("res://Escenas/Menu/Opciones.tscn")


func _on_creditos_boton_pressed() -> void:
	pass # Replace with function body.


func _on_salir_boton_pressed() -> void:
	get_tree().quit()
